# TinyURL的设计要求

